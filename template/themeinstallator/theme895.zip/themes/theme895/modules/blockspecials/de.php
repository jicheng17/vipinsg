<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockspecials}prestashop>blockspecials_c19ed4ea98cbf319735f6d09bde6c757'] = 'Block Sonderangebote';
$_MODULE['<{blockspecials}prestashop>blockspecials_42bcf407ca1621390ed7cbea2b2c0c62'] = 'Fügt einen Block mit aktuellen Sonderangeboten hinzu.';
$_MODULE['<{blockspecials}prestashop>blockspecials_c888438d14855d7d96a2724ee9c306bd'] = 'Einstellungen aktualisiert';
$_MODULE['<{blockspecials}prestashop>blockspecials_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blockspecials}prestashop>blockspecials_41385d2dca40c2a2c7062ed7019a20be'] = 'Block immer anzeigen';
$_MODULE['<{blockspecials}prestashop>blockspecials_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Aktiviert';
$_MODULE['<{blockspecials}prestashop>blockspecials_b9f5c797ebbf55adccdd8539a65a0241'] = 'Deaktiviert';
$_MODULE['<{blockspecials}prestashop>blockspecials_a8a670d89a6d2f3fa59942fc591011ef'] = 'Block anzeigen, auch wenn kein Produkt verfügbar ist.';
$_MODULE['<{blockspecials}prestashop>blockspecials_805b7a76c72691ce8af0a5f458280237'] = 'Anzahl der Cache-Dateien';
$_MODULE['<{blockspecials}prestashop>blockspecials_3744927eb20f857847c982a14df23b69'] = 'Sondrangebote werden nach Zufallsauswahl im Front Office angezeigt. Um ndafür nicht zuviel Ressourcen zu binden, soltten die Ergebnisse gecaxht werden. Der Cache-Speicher wird täglich aktualisiert. Eingabe von 0 deaktiviert das Caching.';
$_MODULE['<{blockspecials}prestashop>blockspecials_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{blockspecials}prestashop>blockspecials_d1aa22a3126f04664e0fe3f598994014'] = 'Sonderangebote';
$_MODULE['<{blockspecials}prestashop>blockspecials_b4f95c1ea534936cc60c6368c225f480'] = 'Alle Specials';
$_MODULE['<{blockspecials}prestashop>blockspecials_077a28bcf4e93718e678ec57128669a3'] = 'Aktuell keine Sonderangebote';
$_MODULE['<{blockspecials}prestashop>blockspecials_fd21fcc9fc4c1d5202d6fc11597b3fca'] = 'Keine Specials zu diesem Zeitpunkt';
