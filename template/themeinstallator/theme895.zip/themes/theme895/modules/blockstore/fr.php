<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockstore}prestashop>blockstore_68e9ecb0ab69b1121fe06177868b8ade'] = 'Bloc magasins';
$_MODULE['<{blockstore}prestashop>blockstore_2d7884c3777bd04028c4a55a820880a8'] = 'Affiche un bloc avec un lien vers la liste des magasins';
$_MODULE['<{blockstore}prestashop>blockstore_126b21ce46c39d12c24058791a236777'] = 'image non valable';
$_MODULE['<{blockstore}prestashop>blockstore_df7859ac16e724c9b1fba0a364503d72'] = 'une erreur s\'est produite lors de l\'envoi';
$_MODULE['<{blockstore}prestashop>blockstore_efc226b17e0532afff43be870bff0de7'] = 'Paramètres mis à jour';
$_MODULE['<{blockstore}prestashop>blockstore_151e79863510ec66281329505bf9fbde'] = 'Configuration du bloc magasins';
$_MODULE['<{blockstore}prestashop>blockstore_2dd1d28275cdb8b78ebd17f6e25aac0d'] = 'Image du bloc';
$_MODULE['<{blockstore}prestashop>blockstore_8c38cf08a0d0a01bd44c682479432350'] = 'Changer l\'image :';
$_MODULE['<{blockstore}prestashop>blockstore_3eedfc0fbc9042acf0ecfe0f325428c4'] = 'l\'image sera affichée au format 174x115';
$_MODULE['<{blockstore}prestashop>blockstore_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockstore}prestashop>blockstore_8c0caec5616160618b362bcd4427d97b'] = 'Nos magasins';
$_MODULE['<{blockstore}prestashop>blockstore_142fe29b7422147cdac10259a0333c11'] = 'Découvrez nos magasins';
$_MODULE['<{blockstore}prestashop>blockstore_34c869c542dee932ef8cd96d2f91cae6'] = 'Nos magasins';
$_MODULE['<{blockstore}prestashop>blockstore_61d5070a61ce6eb6ad2a212fdf967d92'] = 'Découvrez nos magasins';
$_MODULE['<{blockstore}prestashop>blockstore_28fe12f949fd191685071517628df9b3'] = 'Découvrez nos magasins!';
