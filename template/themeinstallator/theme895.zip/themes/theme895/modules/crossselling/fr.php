<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{crossselling}prestashop>crossselling_a1892c39b2598b4f30f9cc92c59f1aa5'] = 'Ventes croisées';
$_MODULE['<{crossselling}prestashop>crossselling_ef2b66b0b65479e08ff0cce29e19d006'] = 'Les clients qui ont acheté ce produit ont également acheté...';
$_MODULE['<{crossselling}prestashop>crossselling_462390017ab0938911d2d4e964c0cab7'] = 'Paramètres mis à jour';
$_MODULE['<{crossselling}prestashop>crossselling_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{crossselling}prestashop>crossselling_b6bf131edd323320bac67303a3f4de8a'] = 'Afficher le prix du produit';
$_MODULE['<{crossselling}prestashop>crossselling_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{crossselling}prestashop>crossselling_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{crossselling}prestashop>crossselling_70f9a895dc3273d34a7f6d14642708ec'] = 'Afficher le prix du produit dans le block';
$_MODULE['<{crossselling}prestashop>crossselling_8ce2b5b3ffa27a8a66220a49357a1582'] = 'Détermine le nombre de produits affichés dans ce bloc';
$_MODULE['<{crossselling}prestashop>crossselling_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{crossselling}prestashop>crossselling_dd1f775e443ff3b9a89270713580a51b'] = 'Précédent';
$_MODULE['<{crossselling}prestashop>crossselling_4351cfebe4b61d8aa5efa1d020710005'] = 'Voir';
$_MODULE['<{crossselling}prestashop>crossselling_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Suivant';
