<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'The block configuration has been updated.';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_dd7bf230fde8d4836917806aff6a6b27'] = 'Address';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_1f8261d17452a959e013666c5df45e07'] = 'Phone number';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'Email';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_d0398e90769ea6ed2823a3857bcc19ea'] = 'Tel';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_6a1e265f92087bb6dd18194833fe946b'] = 'Email';
