<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_632535e0cdfd3380906f6b7d40ba78d3'] = 'Bloc infos contact';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_86458ae1631be34a6fcbf1a4584f5abe'] = 'Ajoute un bloc permettant d\'afficher des informations sur les moyens de contacter la boutique';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configuration mise à jour';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_c281f92b77ba329f692077d23636f5c9'] = 'Nom de la société';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_dd7bf230fde8d4836917806aff6a6b27'] = 'Adresse';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_1f8261d17452a959e013666c5df45e07'] = 'Numéro de téléphone';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'Email';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_b17f3f4dcf653a5776792498a9b44d6a'] = 'Mettre à jour la configuration';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_02d4482d332e1aef3437cd61c9bcc624'] = 'Contactez-nous';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_2e006b735fbd916d8ab26978ae6714d4'] = 'Tél. :';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_d0398e90769ea6ed2823a3857bcc19ea'] = 'Tél :';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_6a1e265f92087bb6dd18194833fe946b'] = 'e-Mail :';
