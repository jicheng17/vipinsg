<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocklink}prestashop>blocklink_3b3d06023f6353f8fd05f859b298573e'] = 'URL:';
$_MODULE['<{blocklink}prestashop>blocklink_f16b5952df8d25ea30b25ff95ee8fedf'] = 'Shop association:';
$_MODULE['<{blocklink}prestashop>blocklink_06933067aafd48425d67bcb01bba5cb6'] = 'Update';
$_MODULE['<{blocklink}prestashop>blocklink_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{blocklink}prestashop>blocklink_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{blocklink}prestashop>blocklink_e6b391a8d2c4d45902a23a8b6585703d'] = 'URL';
$_MODULE['<{blocklink}prestashop>blocklink_06df33001c1d7187fdd81ea1f5b277aa'] = 'Actions';
