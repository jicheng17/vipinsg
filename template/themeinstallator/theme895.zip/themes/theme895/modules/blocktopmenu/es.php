<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocktopmenu}theme_b3>blocktopmenu_af1b98adf7f686b84cd0b443e022b7a0'] = 'Categorías';
