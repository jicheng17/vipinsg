<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocklanguages}prestashop>blocklanguages_0885f0c211f74834f0109c5abaf4cdc4'] = 'Lengua:';
