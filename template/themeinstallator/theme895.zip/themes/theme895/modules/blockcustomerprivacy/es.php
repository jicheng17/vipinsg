<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_f2ec0fd2abc5714608241a1a0eac321b'] = 'Bloque de privacidad de datos de los clientes';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_cb6b92b60c9302e74a26ac246d0af0fa'] = 'Agrega un bloque para mostrar un mensaje respecto a la privacidad de los datos.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_d71315851e7e67cbacf5101c5c4ab83d'] = 'El dato personal que da esta utilizado para responder a sus búsquedas, procesa sus ordenes o autorizase el acceso especifico a la información.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_b43d08355db3df47796e65c72cfd5714'] = 'Tiene derecho de modificar todas las informaciones personales que tenemos sobre usted en pagina \"my account\".';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configuración actualizada';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_d8b716e21c731aba4b94ba9f3ac4858c'] = 'Mensaje sobre la privacidad de datos de los clientes';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_03e1a999dcdb904300ee1b1e767c83c9'] = 'Mensaje que se mostrará en el formulario de creación de la cuenta.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_b51d73fb490ad1245fa9b87042bbbbb7'] = 'Recorde que si el texto es demasiado largo para estar escrito directamente en el campo, puede añadir un enlace en una de sus paginas creadas con la pagina “CMS” bajo el menú “Preferencias”.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_fb32badede7c8613fddb8502d847c18b'] = 'Por favor, acepte el acuerdo sobre la privacidad de los datos de los clientes marcando la casilla de abajo.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_fb0440f9ca32a8b49eded51b09e70821'] = 'Privacidad de los datos de los clientes';
