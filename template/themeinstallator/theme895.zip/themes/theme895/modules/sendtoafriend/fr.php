<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{sendtoafriend}prestashop>product_page_2107f6398c37b4b9ee1e1b5afb5d3b2a'] = 'Envoyer à un ami';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend-extra_d1f092e79827eaffce4a33fa011fde24'] = 'Vous n\'avez pas rempli les champs requis';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend-extra_2107f6398c37b4b9ee1e1b5afb5d3b2a'] = 'Envoyer à un ami';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend-extra_5d6103b662f41b07e10687f03aca8fdc'] = 'Destinataire';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend-extra_bb6aa0be8236a10e6d3b315ebd5f2547'] = 'Nom de votre ami';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend-extra_099bc8914b5be9e522a29e48cb3c01c4'] = 'Adresse e-mail de votre ami';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend-extra_70397c4b252a5168c5ec003931cea215'] = 'Champs requis';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend-extra_ea4788705e6873b424c65e91c2846b19'] = 'Annuler';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend-extra_e81c4e4f2b7b93b481e13a8553c2ae1b'] = 'ou';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend-extra_94966d90747b97d1f0f206c98a8b1ac3'] = 'Envoyer';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_2074615eb70699e55b1f9289c6c77c25'] = 'Module envoyer à un ami';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_3234e2609dd694d8763c390fe97eba04'] = 'Permet à vos clients d\'envoyer des liens à leurs amis';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_2107f6398c37b4b9ee1e1b5afb5d3b2a'] = 'Envoyer à un ami';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_20589174124c25654cac3736e737d2a3'] = 'Envoyer cette page à un ami susceptible d\'être intéressé par le produit ci-dessous';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_b31afdfa73c89b567778f15180c2dd6c'] = 'Votre email a bien été envoyé';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_e55de03786f359e2b133f2a74612eba6'] = 'Nom de votre ami :';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_19f41c3d6db934fb2db1840ddefd2c51'] = 'Email de votre ami :';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_2541d938b0a58946090d7abdde0d3890'] = 'Envoyer';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_68728c1897e5936032fe21ffb6b10c2e'] = 'Retour à la fiche produit';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_ajax_22c4733a9ceb239bf825a0cecd1cfaec'] = 'Un ami';
