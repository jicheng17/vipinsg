<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{sendtoafriend}prestashop>sendtoafriend-extra_ea4788705e6873b424c65e91c2846b19'] = 'Cancel';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend-extra_e81c4e4f2b7b93b481e13a8553c2ae1b'] = 'or';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend-extra_94966d90747b97d1f0f206c98a8b1ac3'] = 'Send';
