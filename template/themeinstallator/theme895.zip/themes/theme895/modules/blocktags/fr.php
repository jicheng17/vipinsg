<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocktags}prestashop>blocktags_f2568a62d4ac8d1d5b532556379772ba'] = 'Bloc tags';
$_MODULE['<{blocktags}prestashop>blocktags_2a87377a6bc89f0dfe2eafe3b240c19c'] = 'Ajoute un bloc contenant les tags et un lien vers la recherche correspondante';
$_MODULE['<{blocktags}prestashop>blocktags_c484b0cda62bd4dbd9c22d095e1b654c'] = 'Vous devez remplir le champs \"tags affichés\".';
$_MODULE['<{blocktags}prestashop>blocktags_73293a024e644165e9bf48f270af63a0'] = 'Nombre non valable.';
$_MODULE['<{blocktags}prestashop>blocktags_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour';
$_MODULE['<{blocktags}prestashop>blocktags_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{blocktags}prestashop>blocktags_a2701a006c71c9097d80ea1ddaea8fa9'] = 'Tags affichés';
$_MODULE['<{blocktags}prestashop>blocktags_2ae74fc125d2af584b168312cdf79dc0'] = 'Nombre de tags affichés dans le bloc';
$_MODULE['<{blocktags}prestashop>blocktags_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blocktags}prestashop>blocktags_189f63f277cd73395561651753563065'] = 'Tags';
$_MODULE['<{blocktags}prestashop>blocktags_49fa2426b7903b3d4c89e2c1874d9346'] = 'En savoir plus sur';
$_MODULE['<{blocktags}prestashop>blocktags_4e6307cfde762f042d0de430e82ba854'] = 'Aucun tag spécifié pour le moment';
$_MODULE['<{blocktags}prestashop>blocktags_70d5e9f2bb7bcb17339709134ba3a2c6'] = 'Aucun tag spécifié pour le moment';
