<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocktags}prestashop>blocktags_f2568a62d4ac8d1d5b532556379772ba'] = 'Блок тегов';
$_MODULE['<{blocktags}prestashop>blocktags_2a87377a6bc89f0dfe2eafe3b240c19c'] = 'Добавляет блок, содержащий облако тегов.';
$_MODULE['<{blocktags}prestashop>blocktags_c484b0cda62bd4dbd9c22d095e1b654c'] = 'Пожалуйста, заполните поле \"отображаемые теги\"';
$_MODULE['<{blocktags}prestashop>blocktags_73293a024e644165e9bf48f270af63a0'] = 'Неверный номер';
$_MODULE['<{blocktags}prestashop>blocktags_c888438d14855d7d96a2724ee9c306bd'] = 'Настройки обновлены';
$_MODULE['<{blocktags}prestashop>blocktags_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{blocktags}prestashop>blocktags_a2701a006c71c9097d80ea1ddaea8fa9'] = 'Количество тегов';
$_MODULE['<{blocktags}prestashop>blocktags_2ae74fc125d2af584b168312cdf79dc0'] = 'Укажите количество тегов, для отображения в этом блоке';
$_MODULE['<{blocktags}prestashop>blocktags_c9cc8cce247e49bae79f15173ce97354'] = 'Сохоранить';
$_MODULE['<{blocktags}prestashop>blocktags_189f63f277cd73395561651753563065'] = 'Тэги';
$_MODULE['<{blocktags}prestashop>blocktags_49fa2426b7903b3d4c89e2c1874d9346'] = 'Подробнее о';
$_MODULE['<{blocktags}prestashop>blocktags_4e6307cfde762f042d0de430e82ba854'] = 'Метки пока не установлены';
$_MODULE['<{blocktags}prestashop>blocktags_70d5e9f2bb7bcb17339709134ba3a2c6'] = 'Тэги еще не созданы';
